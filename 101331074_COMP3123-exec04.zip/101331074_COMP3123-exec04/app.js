const express = require('express');
const body_parser = require('body-parser');
const server_port = process.env.PORT || 3000;

let app = express();
app.use(express.json());
app.use(body_parser.json());

// GET REQUEST FOR HELLO:
app.get('/hello', (req, res) => {
    res.send('Hello Express JS');
});

// GET REQUEST FOR USER WITH QUERY STRING TO SEND VALUES:
app.get('/user', (req, res) => {
    const firstName = req.query.firstname;
    const lastName = req.query.lastname;

    const send_user = {
        "firstname": firstName,
        "lastname": lastName
    }
    res.send(JSON.stringify(send_user));
});

// GET POST FOR USER WITH PATH PARAMETERS TO SEND VALUES:
app.post('/user/:firstName/:lastName', (req, res) => {
    const {firstName, lastName} = req.params

    const send_user = {
        "firstName": firstName,
        "lastName": lastName
    }
    res.send(JSON.stringify(send_user));
});

app.listen(server_port, () => {
    console.log(`Server listening on port ${server_port}`);
});


